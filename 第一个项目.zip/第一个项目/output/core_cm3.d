.\output\core_cm3.o: core\core_cm3.c
.\output\core_cm3.o: D:\keil C51\ARM\ARMCC\Bin\..\include\stdint.h
